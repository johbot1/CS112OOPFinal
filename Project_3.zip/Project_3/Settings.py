'''
Created on May 1, 2023
@author: johnbotonakis
'''
HEIGHT = 720    # Height of the window
WIDTH = 1280    # Width of the window
ACC = 0.8       # Acceleration multiplier
FRIC = -0.12    # Friction multiplier
FPS = 60        # Frames per Second/Tick Rate